import type { ReactNode } from "react";
import type { Route } from "../types";

const items: Array<[Route, string, string]> = [
  ["feed", "⌂", "Лента"],
  ["explore", "⌕", "Поиск"],
  ["picker", "⊞", "Создать"],
  ["reels", "▱", "Reels"],
  ["profile", "●", "Профиль"],
];

export function Brand() {
  return <span className="brand">gloomi</span>;
}

export function Shell({
  route,
  go,
  children,
  immersive = false,
}: {
  route: Route;
  go: (route: Route) => void;
  children: ReactNode;
  immersive?: boolean;
}) {
  if (immersive) return <>{children}</>;
  return (
    <div className="app-shell">
      <aside className="desktop-nav">
        <Brand />
        <nav aria-label="Основная навигация">
          {items.map(([id, icon, label]) => (
            <button className={route === id ? "active" : ""} key={id} onClick={() => go(id)}>
              <span>{icon}</span>
              {label}
            </button>
          ))}
          <button
            className={route === "notifications" ? "active" : ""}
            onClick={() => go("notifications")}
          >
            <span>♡</span>Уведомления
          </button>
          <button
            className={route === "direct" || route === "chat" ? "active" : ""}
            onClick={() => go("direct")}
          >
            <span>◇</span>Сообщения
          </button>
        </nav>
        <button className="account" onClick={() => go("profile")}>
          <img src="/assets/3990c.png" alt="" /> masha.ivanova
        </button>
      </aside>
      <main className="page">{children}</main>
      <nav className="bottom-nav" aria-label="Основная навигация">
        {items.map(([id, icon, label]) => (
          <button className={route === id ? "active" : ""} key={id} onClick={() => go(id)}>
            <span>{icon}</span>
            <small>{label}</small>
          </button>
        ))}
      </nav>
    </div>
  );
}

export function Header({
  title,
  back,
  action,
}: {
  title: string;
  back?: () => void;
  action?: ReactNode;
}) {
  return (
    <header className="page-header">
      {back ? (
        <button className="icon-button" onClick={back} aria-label="Назад">
          ←
        </button>
      ) : (
        <span />
      )}
      <h1>{title}</h1>
      {action ?? <span />}
    </header>
  );
}
