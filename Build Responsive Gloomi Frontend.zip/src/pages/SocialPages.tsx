import { useMemo, useState } from "react";
import { A, conversations, gridImages, storyUsers } from "../data/mockData";
import { Brand, Header } from "../components/Shell";
import type { Route } from "../types";

type Go = (route: Route) => void;

export function Feed({ go }: { go: Go }) {
  const [liked, setLiked] = useState(true);
  const [saved, setSaved] = useState(true);
  const [comments, setComments] = useState(["masha.ivanova Тот самый идеальный день 🤍"]);
  const [draft, setDraft] = useState("");
  const [showComments, setShowComments] = useState(false);
  return (
    <div className="content-column feed">
      <header className="feed-header">
        <Brand />
        <div>
          <button onClick={() => go("notifications")}>♡</button>
          <button onClick={() => go("direct")}>
            ⌁<i />
          </button>
        </div>
      </header>
      <div className="stories">
        {storyUsers.map(([name, image], index) => (
          <button key={name} onClick={() => go("story")}>
            <span>
              <img src={`${A}/${image}`} alt="" />
              {index === 0 && <b>+</b>}
            </span>
            <small>{name}</small>
          </button>
        ))}
      </div>
      <article className="post-card">
        <header>
          <button onClick={() => go("profile")}>
            <img src={`${A}/f3806.png`} alt="" />
            <span>
              <b>anna.sokolova</b>
              <small>Амальфи, Италия · 2 часа назад</small>
            </span>
          </button>
          <button>•••</button>
        </header>
        <button className="post-media" aria-label="Открыть публикацию">
          <img src={`${A}/b1ceb.png`} alt="Сюрреалистичный портрет" />
          <span>1/3</span>
        </button>
        <div className="post-actions">
          <button className={liked ? "liked" : ""} onClick={() => setLiked(!liked)}>
            {liked ? "♥" : "♡"}
          </button>
          <button onClick={() => setShowComments(!showComments)}>○</button>
          <button>⌁</button>
          <span className="pager">● · ·</span>
          <button onClick={() => setSaved(!saved)}>{saved ? "▮" : "▯"}</button>
        </div>
        <div className="caption">
          <b>Нравится {liked ? "1 248" : "1 247"} людям</b>
          <p>
            <b>anna.sokolova</b> Маленькая жизнь у большого моря.
            <br />
            Здесь хочется замедлиться ☀️
          </p>
          <small>Все комментарии: {comments.length + 35}</small>
          {comments.map((c) => (
            <p key={c}>{c}</p>
          ))}
        </div>
        {showComments && (
          <form
            className="comment-box"
            onSubmit={(e) => {
              e.preventDefault();
              if (draft.trim()) {
                setComments([...comments, `masha.ivanova ${draft}`]);
                setDraft("");
              }
            }}
          >
            <input
              value={draft}
              onChange={(e) => setDraft(e.target.value)}
              placeholder="Добавить комментарий…"
            />
            <button disabled={!draft.trim()}>Отправить</button>
          </form>
        )}
      </article>
    </div>
  );
}

export function Explore({ go }: { go: Go }) {
  return (
    <div className="content-column">
      <Header title="Вдохновение рядом" action={<button>☷</button>} />
      <button className="search-field" onClick={() => go("search")}>
        ⌕ <span>Люди, места и вдохновение</span>
      </button>
      <div className="chips">
        <button>Лето в городе</button>
        <button>Архитектура</button>
        <button>Slow life</button>
      </div>
      <div className="mosaic">
        {["8265a.png", "bf2b1.png", "103f6.png", "d6c8d.png", "eaf8b.png"].map((im, i) => (
          <button key={im} className={i === 2 ? "tall" : ""}>
            <img src={`${A}/${im}`} alt="" />
          </button>
        ))}
      </div>
      <section className="rhythm">
        <div className="section-title">
          <h2>В вашем ритме</h2>
          <button>Все</button>
        </div>
        <div className="suggestions">
          <button>
            <img src={`${A}/513ca.png`} alt="" />
            <span>
              <b>max.orton</b>
              <small>Фото и путешествия</small>
            </span>
          </button>
          <button>
            <img src={`${A}/be12a.png`} alt="" />
            <span>
              <b>dasha.live</b>
              <small>Маленькие радости</small>
            </span>
          </button>
        </div>
      </section>
      <div className="explore-row">
        {["596ce.png", "131f2.png", "675be.png"].map((im) => (
          <img src={`${A}/${im}`} key={im} alt="" />
        ))}
      </div>
    </div>
  );
}

export function Search() {
  const [query, setQuery] = useState("лето");
  const [tab, setTab] = useState("Для вас");
  return (
    <div className="content-column search-page">
      <div className="search-top">
        ←
        <label>
          ⌕<input autoFocus value={query} onChange={(e) => setQuery(e.target.value)} />
          <button onClick={() => setQuery("")}>×</button>
        </label>
      </div>
      <div className="tabs">
        {["Для вас", "Люди", "Публикации", "Теги"].map((t) => (
          <button className={tab === t ? "active" : ""} onClick={() => setTab(t)} key={t}>
            {t}
          </button>
        ))}
      </div>
      <div className="section-title">
        <h2>Люди</h2>
        <button>Все</button>
      </div>
      {[
        ["summer.with.anya", "Аня · лето круглый год", "4a75f.png"],
        ["leto.studio", "ЛЕТО / керамика и дом", "02506.png"],
      ]
        .filter((x) => x[0].includes(query.toLowerCase()) || query === "лето")
        .map((x) => (
          <button className="person-row" key={x[0]}>
            <img src={`${A}/${x[2]}`} alt="" />
            <span>
              <b>{x[0]}</b>
              <small>{x[1]}</small>
            </span>
            ›
          </button>
        ))}
      <h2 className="subheading">Хэштеги</h2>
      <div className="hashtags">
        <button>
          #летовмоменте<small>24,8 тыс. публикаций</small>
        </button>
        <button>
          #летовгороде<small>8 420 публикаций</small>
        </button>
      </div>
      <div className="section-title">
        <h2>Публикации</h2>
        <button>Больше</button>
      </div>
      <div className="result-posts">
        <button>
          <img src={`${A}/675be.png`} alt="" />
          <b>Маленькая жизнь у моря</b>
          <small>anna.sokolova · 1 248 ♡</small>
        </button>
        <button>
          <img src={`${A}/b8dec.png`} alt="" />
          <b>Лето, которое внутри</b>
          <small>dasha.live · 862 ♡</small>
        </button>
      </div>
    </div>
  );
}

export function Profile() {
  const [tab, setTab] = useState("Публикации");
  const [editing, setEditing] = useState(false);
  return (
    <div className="content-column profile-page">
      <Header title="masha.ivanova" action={<button>☰</button>} />
      <section className="profile-summary">
        <img src={`${A}/1aa6d.png`} alt="" />
        <div>
          <b>
            48<small>публикаций</small>
          </b>
          <b>
            2 841<small>подписчик</small>
          </b>
          <b>
            612<small>подписок</small>
          </b>
        </div>
      </section>
      {editing ? (
        <div className="edit-card">
          <input defaultValue="Маша Иванова" />
          <textarea defaultValue="Собираю моменты, а не вещи. Москва · кофе · города без маршрута" />
          <button onClick={() => setEditing(false)}>Сохранить</button>
        </div>
      ) : (
        <div className="bio">
          <b>Маша Иванова</b>
          <p>Собираю моменты, а не вещи. Москва · кофе · города без маршрута</p>
          <a>Вдохновение в повседневном ↗</a>
        </div>
      )}
      <div className="profile-buttons">
        <button onClick={() => setEditing(true)}>Редактировать</button>
        <button>Поделиться</button>
      </div>
      <div className="highlights">
        {[
          ["Лето", "675be.png"],
          ["Города", "b8dec.png"],
          ["Каждый день", "131f2.png"],
        ].map((x) => (
          <button key={x[0]}>
            <img src={`${A}/${x[1]}`} alt="" />
            <small>{x[0]}</small>
          </button>
        ))}
        <button>
          <span>＋</span>
          <small>Новое</small>
        </button>
      </div>
      <div className="tabs profile-tabs">
        {["Публикации", "Reels", "Сохранённое"].map((t) => (
          <button className={tab === t ? "active" : ""} onClick={() => setTab(t)} key={t}>
            {t}
          </button>
        ))}
      </div>
      <div className="profile-grid">
        {gridImages
          .slice(tab === "Публикации" ? 0 : 3, tab === "Публикации" ? 9 : 9)
          .map((im, i) => (
            <button key={`${im}${i}`}>
              <img src={`${A}/${im}`} alt="" />
            </button>
          ))}
      </div>
    </div>
  );
}

export function Notifications() {
  const [filter, setFilter] = useState("Все");
  const [following, setFollowing] = useState<number[]>([]);
  const rows = useMemo(
    () => [
      ["anna.sokolova нравится ваша публикация.", "5 мин назад", "f3806.png"],
      [
        "dasha.live прокомментировала: «Это утро выглядит идеально ☕»",
        "18 мин назад",
        "be12a.png",
      ],
      ["max.orton теперь подписался на вас.", "42 мин назад", "513ca.png"],
      ["dasha.live упомянула вас в истории.", "Вчера · 19:24", "be12a.png"],
      ["anna.sokolova и ещё 24 оценили вашу публикацию.", "Вчера · 16:08", "f3806.png"],
      ["leto.studio теперь следит за вами.", "2 дня назад", "2d5d4.png"],
    ],
    [],
  );
  return (
    <div className="content-column notifications">
      <Header title="Уведомления" action={<button>☷</button>} />
      <div className="chips">
        {["Все", "Подписки", "Упоминания"].map((x) => (
          <button className={filter === x ? "active" : ""} onClick={() => setFilter(x)} key={x}>
            {x}
          </button>
        ))}
      </div>
      <h2>
        Новое <i />
      </h2>
      {rows.map((r, i) => (
        <div className={i < 3 ? "notification unread" : "notification"} key={r[0]}>
          <img src={`${A}/${r[2]}`} alt="" />
          <span>
            <p>{r[0]}</p>
            <small>{r[1]}</small>
          </span>
          {i === 2 || i === 5 ? (
            <button
              className={following.includes(i) ? "secondary" : "primary"}
              onClick={() =>
                setFollowing(
                  following.includes(i) ? following.filter((x) => x !== i) : [...following, i],
                )
              }
            >
              {following.includes(i) ? "Вы подписаны" : "Подписаться"}
            </button>
          ) : (
            <img className="thumb" src={`${A}/b1ceb.png`} alt="" />
          )}
        </div>
      ))}
    </div>
  );
}

export function Direct({ go }: { go: Go }) {
  const [query, setQuery] = useState("");
  return (
    <div className="messages-layout">
      <div className="inbox content-column">
        <Header title="Сообщения" action={<button>□</button>} />
        <label className="search-field">
          ⌕
          <input
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            placeholder="Поиск в сообщениях"
          />
        </label>
        <div className="inbox-tabs">
          <b>Личные</b>
          <button>Запросы · 3</button>
        </div>
        {conversations
          .filter((c) => c.name.toLowerCase().includes(query.toLowerCase()))
          .map((c) => (
            <button className="conversation" onClick={() => go("chat")} key={c.id}>
              <img src={c.avatar} alt="" />
              <span>
                <b>{c.name}</b>
                <small>{c.preview}</small>
              </span>
              <time>{c.time}</time>
              {c.unread && <i>{c.unread}</i>}
            </button>
          ))}
        <p className="private-note">▣ Личное остаётся личным</p>
      </div>
      <div className="desktop-chat">
        <Chat go={go} embedded />
      </div>
    </div>
  );
}

export function Chat({ go, embedded = false }: { go: Go; embedded?: boolean }) {
  const [messages, setMessages] = useState([
    "Аня, спасибо! Это всё утренний свет ✨",
    "Может, повторим это утро в субботу?",
  ]);
  const [draft, setDraft] = useState("");
  return (
    <div className={embedded ? "chat-view embedded" : "content-column chat-view"}>
      <header className="chat-header">
        <button onClick={() => go("direct")}>←</button>
        <img src={`${A}/f3806.png`} alt="" />
        <span>
          <b>Анна Соколова</b>
          <small>В сети</small>
        </span>
        <button>♧</button>
        <button>▭</button>
      </header>
      <div className="messages">
        <time>СЕГОДНЯ, 10:24</time>
        <div className="bubble received">Маша, привет! Как же красиво у тебя в ленте 🤍</div>
        {messages.map((m, i) => (
          <div className="bubble sent" key={m}>
            {m}
            <small>10:2{i + 6} · Прочитано</small>
          </div>
        ))}
        <img className="shared-photo" src={`${A}/131f2.png`} alt="" />
        <small>Вы поделились публикацией · 10:27</small>
        <div className="bubble received">Давай! Знаю одно классное место ☕</div>
      </div>
      <form
        className="message-composer"
        onSubmit={(e) => {
          e.preventDefault();
          if (draft.trim()) {
            setMessages([...messages, draft]);
            setDraft("");
          }
        }}
      >
        <input value={draft} onChange={(e) => setDraft(e.target.value)} placeholder="Сообщение…" />
        <button disabled={!draft.trim()}>➤</button>
      </form>
    </div>
  );
}
