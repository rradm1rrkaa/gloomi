import { useEffect, useRef, useState } from "react";
import { A } from "../data/mockData";
import { Header } from "../components/Shell";
import { mockPublicationService } from "../services/publicationService";
import type { LocalMedia, Route } from "../types";

type Go = (route: Route) => void;

export function Story({ go }: { go: Go }) {
  const [segment, setSegment] = useState(0);
  const [reply, setReply] = useState("");
  useEffect(() => {
    const timer = window.setInterval(() => setSegment((s) => (s >= 2 ? 0 : s + 1)), 4000);
    return () => window.clearInterval(timer);
  }, []);
  return (
    <div
      className="immersive story-view"
      onClick={(e) => {
        if ((e.target as HTMLElement).closest("button,input")) return;
        setSegment((s) => Math.min(2, s + 1));
      }}
    >
      <div className="story-media">
        <img src={`${A}/bf5da.png`} alt="Снежный барс" />
        <div className="story-progress">
          {[0, 1, 2].map((i) => (
            <i className={i <= segment ? "done" : ""} key={i} />
          ))}
        </div>
        <header>
          <img src={`${A}/f3806.png`} alt="" />
          <span>
            <b>anna.sokolova</b>
            <small>28 мин назад · Из архива</small>
          </span>
          <button>•••</button>
          <button onClick={() => go("feed")}>×</button>
        </header>
        <div className="story-caption">
          Йо нига зач ты
          <br />
          кинул меня <span>⌖ ЛИССАБОН, ПОРТУГАЛИЯ</span>
        </div>
        <small className="audio">♫ Khruangbin · Friday Morning</small>
      </div>
      <form
        onSubmit={(e) => {
          e.preventDefault();
          setReply("");
        }}
      >
        <input
          value={reply}
          onChange={(e) => setReply(e.target.value)}
          placeholder="Написать Анне…"
        />
        <button>♡</button>
        <button>⌁</button>
      </form>
    </div>
  );
}

export function Reels({ go }: { go: Go }) {
  const [playing, setPlaying] = useState(true);
  const [muted, setMuted] = useState(true);
  const [liked, setLiked] = useState(false);
  const [follow, setFollow] = useState(false);
  return (
    <div className="immersive reel-view">
      <img className="reel-poster" src={`${A}/eaf8b.png`} alt="Reel" />
      <div className="reel-shade" />
      <header>
        <h1>Reels</h1>
        <button>▣</button>
      </header>
      <button className="play" onClick={() => setPlaying(!playing)}>
        {playing ? "Ⅱ" : "▷"}
      </button>
      <button className="mute" onClick={() => setMuted(!muted)}>
        {muted ? "⌁" : "♪"}
      </button>
      <div className="reel-actions">
        <button onClick={() => setLiked(!liked)}>
          {liked ? "♥" : "♡"}
          <small>{liked ? "8 427" : "8 426"}</small>
        </button>
        <button>
          ◯<small>128</small>
        </button>
        <button>
          ⌁<small>246</small>
        </button>
        <button>▯</button>
      </div>
      <div className="reel-copy">
        <div>
          <img src={`${A}/513ca.png`} alt="" />
          <b>max.orton</b>
          <button onClick={() => setFollow(!follow)}>
            {follow ? "Вы подписаны" : "Подписаться"}
          </button>
        </div>
        <p>Между планами и волнами — выбираю волны 🌊</p>
        <small>#oceantherapy #свойритм</small>
        <small>♫ Petit Biscuit · Sunset Lover</small>
      </div>
      <nav className="dark-bottom">
        <button onClick={() => go("feed")}>
          ⌂<small>Лента</small>
        </button>
        <button onClick={() => go("explore")}>
          ⌕<small>Поиск</small>
        </button>
        <button onClick={() => go("picker")}>
          ⊞<small>Создать</small>
        </button>
        <button className="active">
          ▱<small>Reels</small>
        </button>
        <button onClick={() => go("profile")}>
          ●<small>Профиль</small>
        </button>
      </nav>
    </div>
  );
}

export function MediaPicker({
  go,
  media,
  setMedia,
  mode,
  setMode,
}: {
  go: Go;
  media: LocalMedia[];
  setMedia: (m: LocalMedia[]) => void;
  mode: "Публикация" | "История" | "Reels";
  setMode: (m: "Публикация" | "История" | "Reels") => void;
}) {
  const [active, setActive] = useState(0);
  const input = useRef<HTMLInputElement>(null);
  const cameraInput = useRef<HTMLInputElement>(null);
  const [dragging, setDragging] = useState(false);
  const addFiles = (files: FileList | File[]) => {
    const next = [...files]
      .filter((f) => f.type.startsWith("image/") || f.type.startsWith("video/"))
      .map((file) => ({
        id: crypto.randomUUID(),
        file,
        url: URL.createObjectURL(file),
        type: file.type.startsWith("video/") ? ("video" as const) : ("image" as const),
      }));
    setMedia([...media, ...next]);
    setActive(media.length);
  };
  const remove = (index: number) => {
    URL.revokeObjectURL(media[index].url);
    const next = media.filter((_, i) => i !== index);
    setMedia(next);
    setActive(Math.max(0, Math.min(active, next.length - 1)));
  };
  return (
    <div className="creator">
      <Header
        title="Новая публикация"
        back={() => go("feed")}
        action={
          <button className="next" disabled={!media.length} onClick={() => go("details")}>
            Далее
          </button>
        }
      />
      <div className="picker-layout">
        <section
          className={`media-preview ${dragging ? "dragging" : ""}`}
          onDragOver={(e) => {
            e.preventDefault();
            setDragging(true);
          }}
          onDragLeave={() => setDragging(false)}
          onDrop={(e) => {
            e.preventDefault();
            setDragging(false);
            addFiles(e.dataTransfer.files);
          }}
        >
          {media[active] ? (
            <>
              {media[active].type === "video" ? (
                <video src={media[active].url} controls />
              ) : (
                <img src={media[active].url} alt="Выбранный файл" />
              )}
              <b>
                {active + 1}/{media.length}
              </b>
            </>
          ) : (
            <button onClick={() => input.current?.click()}>
              <span>↑</span>
              <b>Перетащите фото и видео сюда</b>
              <small>или выберите файлы на устройстве</small>
            </button>
          )}
        </section>
        <section className="gallery">
          <div className="gallery-toolbar">
            <b>Недавние⌄</b>
            <span />
            <button onClick={() => input.current?.click()}>▣ Выбрать</button>
            <button onClick={() => cameraInput.current?.click()}>◎</button>
          </div>
          <div className="media-grid">
            {media.map((item, i) => (
              <button
                className={active === i ? "active" : ""}
                onClick={() => setActive(i)}
                key={item.id}
              >
                {item.type === "video" ? <video src={item.url} /> : <img src={item.url} alt="" />}
                <i>{i + 1}</i>
                <span
                  onClick={(e) => {
                    e.stopPropagation();
                    remove(i);
                  }}
                >
                  ×
                </span>
              </button>
            ))}
            {!media.length &&
              gridFallback.map((im, i) => (
                <button onClick={() => input.current?.click()} key={im}>
                  <img src={`${A}/${im}`} alt="" />
                  <i>{i === 0 ? "＋" : ""}</i>
                </button>
              ))}
          </div>
        </section>
      </div>
      <input
        ref={input}
        hidden
        type="file"
        accept="image/*,video/*"
        multiple
        onChange={(e) => e.target.files && addFiles(e.target.files)}
      />
      <input
        ref={cameraInput}
        hidden
        type="file"
        accept="image/*"
        capture="environment"
        onChange={(e) => e.target.files && addFiles(e.target.files)}
      />
      <div className="mode-tabs">
        {(["Публикация", "История", "Reels"] as const).map((x) => (
          <button className={mode === x ? "active" : ""} onClick={() => setMode(x)} key={x}>
            {x}
          </button>
        ))}
      </div>
    </div>
  );
}
const gridFallback = [
  "131f2.png",
  "8265a.png",
  "b8dec.png",
  "675be.png",
  "d6c8d.png",
  "596ce.png",
  "93335.png",
  "e6e8e.png",
  "1f17f.png",
  "bf2b1.png",
  "103f6.png",
  "b1ceb.png",
];

export function Details({
  go,
  media,
  mode,
  onDone,
}: {
  go: Go;
  media: LocalMedia[];
  mode: "Публикация" | "История" | "Reels";
  onDone: () => void;
}) {
  const [caption, setCaption] = useState("");
  const [location, setLocation] = useState("Кофейня «Слой»");
  const [comments, setComments] = useState(true);
  const [state, setState] = useState<"idle" | "uploading" | "success" | "error">("idle");
  const [progress, setProgress] = useState(0);
  const publish = async () => {
    setState("uploading");
    try {
      await mockPublicationService.publish({ media, caption, location, mode }, setProgress);
      setState("success");
      window.setTimeout(() => {
        onDone();
        go("feed");
      }, 900);
    } catch {
      setState("error");
    }
  };
  return (
    <div className="content-column details">
      <Header title="Последний штрих" back={() => go("picker")} />
      <div className="author-mini">
        <img src={`${A}/3990c.png`} alt="" />
        <b>masha.ivanova</b>
        <small>· Открытый профиль</small>
      </div>
      <div className="caption-editor">
        {media[0] ? (
          media[0].type === "video" ? (
            <video src={media[0].url} />
          ) : (
            <img src={media[0].url} alt="" />
          )
        ) : (
          <img src={`${A}/131f2.png`} alt="" />
        )}
        <textarea
          maxLength={2200}
          value={caption}
          onChange={(e) => setCaption(e.target.value)}
          placeholder="Напишите подпись…"
        />
        <small>{caption.length} / 2 200</small>
      </div>
      <div className="detail-options">
        <button>
          ♧{" "}
          <span>
            Отметить людей<small>dasha.live</small>
          </span>
          ›
        </button>
        <button>
          ⌖{" "}
          <span>
            Добавить место
            <input value={location} onChange={(e) => setLocation(e.target.value)} />
          </span>
          ›
        </button>
        <button>
          ♫{" "}
          <span>
            Добавить музыку<small>Выбрать трек</small>
          </span>
          ›
        </button>
        <label>
          <span>
            Разрешить комментарии<small>Начните разговор</small>
          </span>
          <input
            type="checkbox"
            checked={comments}
            onChange={(e) => setComments(e.target.checked)}
          />
          <i />
        </label>
      </div>
      <div className="privacy-note">
        ◎ <span>Вашу публикацию увидят все. Настройки можно изменить в любой момент.</span>
      </div>
      {state === "uploading" && (
        <div className="progress">
          <i style={{ width: `${progress}%` }} />
          <span>Загрузка {progress}%</span>
        </div>
      )}
      {state === "error" && <p className="error">Не удалось опубликовать. Попробуйте ещё раз.</p>}
      {state === "success" && <p className="success">Публикация готова</p>}
      <button
        className="publish"
        disabled={!media.length || state === "uploading"}
        onClick={publish}
      >
        {state === "uploading" ? "Публикуем…" : "Опубликовать"}
      </button>
      <button className="draft">Сохранить в черновики</button>
    </div>
  );
}
