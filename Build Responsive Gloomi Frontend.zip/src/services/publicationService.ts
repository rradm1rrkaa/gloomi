import type { LocalMedia } from "../types";

export interface PublishInput {
  media: LocalMedia[];
  caption: string;
  location?: string;
  mode: "Публикация" | "История" | "Reels";
}

export interface PublicationService {
  publish(input: PublishInput, onProgress: (progress: number) => void): Promise<{ id: string }>;
}

// Preview-only adapter. Replace this object with the existing Axios/API service at integration time.
export const mockPublicationService: PublicationService = {
  publish: (_input, onProgress) =>
    new Promise((resolve) => {
      let progress = 0;
      const timer = window.setInterval(() => {
        progress += 20;
        onProgress(progress);
        if (progress >= 100) {
          window.clearInterval(timer);
          resolve({ id: `preview-${Date.now()}` });
        }
      }, 180);
    }),
};
