export type Route =
  | "feed"
  | "explore"
  | "search"
  | "profile"
  | "notifications"
  | "reels"
  | "direct"
  | "chat"
  | "story"
  | "picker"
  | "details";

export interface Conversation {
  id: number;
  name: string;
  handle: string;
  avatar: string;
  preview: string;
  time: string;
  unread?: number;
}

export interface LocalMedia {
  id: string;
  file: File;
  url: string;
  type: "image" | "video";
}
