import type { Conversation } from "../types";

export const A = "/assets";

export const conversations: Conversation[] = [
  {
    id: 1,
    name: "Анна Соколова",
    handle: "anna.sokolova",
    avatar: `${A}/4a75f.png`,
    preview: "Давай! Знаю одно классное место ☕",
    time: "2 мин",
    unread: 2,
  },
  {
    id: 2,
    name: "Даша",
    handle: "dasha.live",
    avatar: `${A}/be12a.png`,
    preview: "Вы: Отправила тебе фотографию 🤍",
    time: "24 мин",
  },
  {
    id: 3,
    name: "Макс Ортон",
    handle: "max.orton",
    avatar: `${A}/513ca.png`,
    preview: "Отправил Reels",
    time: "1 ч",
    unread: 1,
  },
  {
    id: 4,
    name: "ЛЕТО / студия",
    handle: "leto.studio",
    avatar: `${A}/e6e86.png`,
    preview: "Спасибо, будем вас ждать!",
    time: "3 ч",
  },
  {
    id: 5,
    name: "Выходные без плана",
    handle: "weekend",
    avatar: `${A}/3b113.png`,
    preview: "Даша: Ну что, едем в субботу?",
    time: "5 ч",
  },
  {
    id: 6,
    name: "Никита",
    handle: "nikita",
    avatar: `${A}/eaf8b.png`,
    preview: "Крутые кадры получились!",
    time: "Вчера",
  },
];

export const gridImages = [
  "131f2.png",
  "8265a.png",
  "b8dec.png",
  "675be.png",
  "d6c8d.png",
  "596ce.png",
  "93335.png",
  "e6e8e.png",
  "1f17f.png",
];

export const storyUsers = [
  ["Ваша история", "1aa6d.png"],
  ["anna.sokolova", "f3806.png"],
  ["max.orton", "513ca.png"],
  ["dasha.live", "be12a.png"],
  ["places", "57c45.png"],
];
