import { useEffect, useState } from "react";
import { Shell } from "./components/Shell";
import { Chat, Direct, Explore, Feed, Notifications, Profile, Search } from "./pages/SocialPages";
import { Details, MediaPicker, Reels, Story } from "./pages/MediaPages";
import type { LocalMedia, Route } from "./types";

const validRoutes: Route[] = [
  "feed",
  "explore",
  "search",
  "profile",
  "notifications",
  "reels",
  "direct",
  "chat",
  "story",
  "picker",
  "details",
];

export default function App() {
  const initial = location.hash.slice(1) as Route;
  const [route, setRoute] = useState<Route>(validRoutes.includes(initial) ? initial : "feed");
  const [media, setMedia] = useState<LocalMedia[]>([]);
  const [mode, setMode] = useState<"Публикация" | "История" | "Reels">("Публикация");
  const go = (next: Route) => {
    location.hash = next;
    setRoute(next);
    window.scrollTo(0, 0);
  };
  useEffect(() => {
    const onHash = () => {
      const x = location.hash.slice(1) as Route;
      if (validRoutes.includes(x)) setRoute(x);
    };
    addEventListener("hashchange", onHash);
    return () => removeEventListener("hashchange", onHash);
  }, []);
  if (route === "story") return <Story go={go} />;
  if (route === "reels") return <Reels go={go} />;
  if (route === "picker")
    return <MediaPicker go={go} media={media} setMedia={setMedia} mode={mode} setMode={setMode} />;
  if (route === "details")
    return <Details go={go} media={media} mode={mode} onDone={() => setMedia([])} />;
  return (
    <Shell route={route} go={go}>
      {route === "feed" && <Feed go={go} />}
      {route === "explore" && <Explore go={go} />}
      {route === "search" && <Search />}
      {route === "profile" && <Profile />}
      {route === "notifications" && <Notifications />}
      {route === "direct" && <Direct go={go} />}
      {route === "chat" && <Chat go={go} />}
    </Shell>
  );
}
